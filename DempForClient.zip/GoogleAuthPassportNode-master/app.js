
const express = require('express')
const app = express()
const passport = require('passport');
const cookieSession = require('cookie-session');

require('./passport-setup');

UserService = require('./service/UserService');

//start file upload

const multer  = require('multer');
const path = require("path");



app.use('/uploads',express.static(path.join(__dirname,'/uploads')));


const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads');
    },
    filename: (req, file, cb) => {
        console.log(file);
        cb(null, Date.now() + path.extname(file.originalname));
    }
});
const fileFilter = (req, file, cb) => {
    if (file.mimetype == 'image/jpeg' || file.mimetype == 'image/png') {
        cb(null, true);
    } else {
        cb(null, false);
    }
}
const upload = multer({ storage: storage, fileFilter: fileFilter });


//Upload route
app.post('/upload', upload.single('image'), (req, res, next) => {
UserService.adduserdata(req.body).then((result)=>{
  console.log(req.file);
  res.json({message:"file uploading successfull !", data:result})

}).catch((err)=>{

  res.status(400).json({message:"fail to upload !",data:err})
})
    
});

// end



// For an actual app you should configure this with an experation time, better keys, proxy and secure
app.use(cookieSession({
    name: 'tuto-session',
    keys: ['key1', 'key2']
  }))
  
// Initializes passport and passport sessions
app.use(passport.initialize());
app.use(passport.session());


app.set('view engine','ejs')

// Auth middleware that checks if the user is logged in
const isLoggedIn = (req, res, next) => {
    if (req.user) {
        next();
    } else {
        res.sendStatus(401);
    }
}


// Example protected and unprotected routes
app.get('/', (req, res) => res.render('pages/index'))
app.get('/failed', (req, res) => res.send('You Failed to log in!'))

// In this route you can see that if the user is logged in u can acess his info in: req.user
app.get('/success', isLoggedIn, (req, res,next) =>{
    res.render("pages/profile",{name:req.user.displayName,pic:req.user.photos[0].value,email:req.user.emails[0].value})
})

// app.get('/success',(req,res)=>{
//   res.render('pages/profile.ejs')
// })
// Auth Routes
app.get('/google', passport.authenticate('google', { scope: ['profile', 'email'] }));

app.get('/google/callback', passport.authenticate('google', { failureRedirect: '/failed' }),
  function(req, res,next) {
    // Successful authentication, redirect home.
    res.redirect('/success');
    
  }
 
);




app.get('/logout', (req, res) => {
    req.session = null;
    req.logout();
    res.redirect('/');
})
















app.listen(3000, () => console.log(`Example app listening on port ${3000}!`))


