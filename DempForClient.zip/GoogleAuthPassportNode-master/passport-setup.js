const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth2').Strategy;


passport.serializeUser(function(user, done) {
    done(null, user);
  });
  
passport.deserializeUser(function(user, done) {
 
    done(null, user);
});

passport.use(new GoogleStrategy({
    clientID: "125382625161-ed3bii3306lj9catnq3gg9v7qp6v900b.apps.googleusercontent.com",
    clientSecret: "BLktGfRijNyeQ3UAIMeBZ3ai",
    callbackURL: "http://localhost:3000/google/callback",
    passReqToCallback:true
  },
  function(request, accessToken, refreshToken, profile, done) {
    console.log(profile)
    return done(null, profile);
  }
));

module.exports = passport;