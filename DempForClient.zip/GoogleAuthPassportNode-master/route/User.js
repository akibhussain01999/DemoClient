
// var express = require('express');
// var router = express.Router();
// const passport = require('passport');
// const cookieSession = require('cookie-session')
// require('../passport-setup');


// // For an actual router you should configure this with an experation time, better keys, proxy and secure
// router.use(cookieSession({
//     name: 'tuto-session',
//     keys: ['key1', 'key2']
//   }))
  
// // Initializes passport and passport sessions
// router.use(passport.initialize());
// router.use(passport.session());




// // Auth middleware that checks if the user is logged in
// const isLoggedIn = (req, res, next) => {
//     if (req.user) {
//         next();
//     } else {
//         res.sendStatus(401);
//     }
// }


// // Example protected and unprotected routes
// router.get('/', (req, res) => res.render('../pages/index'))
// router.get('/failed', (req, res) => res.send('You Failed to log in!'))

// // In this route you can see that if the user is logged in u can acess his info in: req.user
// router.get('/success', isLoggedIn, (req, res,next) =>{
//     res.render("pages/profile",{name:req.user.displayName,pic:req.user.photos[0].value,email:req.user.emails[0].value})
// })

// // router.get('/success',(req,res)=>{
// //   res.render('pages/profile.ejs')
// // })
// // Auth Routes
// router.get('/google', passport.authenticate('google', { scope: ['profile', 'email'] }));

// router.get('/google/callback', passport.authenticate('google', { failureRedirect: '/failed' }),
//   function(req, res,next) {
//     // Successful authentication, redirect home.
//     res.redirect('/success');
    
//   }
 
// );




// router.get('/logout', (req, res) => {
//     req.session = null;
//     req.logout();
//     res.redirect('/');
// })

// module.exports=router;