var pool = require("../lib/config");


//register user
var adduserdata = (filename) => {
  return new Promise((resolve, reject) => {
    pool
      .query(
        'INSERT INTO userinfo1("filename")VALUES($1)',
        [filename]
      )
      .then((result) => {
        resolve(result.rows[0]);
      })
      .catch((err) => {
        reject(err);
      });
  });
};



module.exports = {
 
  adduserdata: adduserdata,

  
};
